# A Music Language

A Music Language es un lenguaje de programación musical creado para la asignatura de Compiladores del Grado en Ingenieria Informática de la Facultad de Informática de Barcelona de la Universidad Politécnica de Cataluña.

# Pasos para compilación de archivos .music
 - Compilar la gramática escrita en el archivo Music.g
 - Compilar el intérprete.
 - Ejecutar la clase principal localizada en Aml.java pasando como argumento el archivo a compilar.

# Tests

Los tests de la aplicacion están localizados en la carpeta `tests`. Esta carpeta esta organizada en una estructura de subdirectorios con nombres autoexplicativos sobre lo que se está testeando.